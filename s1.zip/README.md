you need a sonic retro sonic 1 .bin by:



1. going to https://github.com/sonicretro/s1disasm
2. clicking code
3. clicking download ZIP
4. extracting all
5. going to s1disasm-AS
6. double clicking build.bat



next, go to https://www.marcrobledo.com/RomPatcher.js/

and then it should be obvious on what to do (make sure you have an emulator like retroarch or something because i'm too lazy to give you it anyways)

